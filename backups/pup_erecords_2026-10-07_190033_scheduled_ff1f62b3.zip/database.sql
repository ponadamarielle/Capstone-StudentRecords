-- PUP eRecords database backup
-- Database: db_pup_eRecords
-- Created: 2026-10-07 19:00:33 PST

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- Table: accounts
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'Registrar',
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `is_first_login` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `accounts` (`id`, `name`, `email`, `pass`, `role`, `status`, `is_first_login`) VALUES
('1', 'Alistair Ravena', 'superadmin@gmail.com', '$2y$10$L2YkceOwIXL7tHoDm04fseH7a1hEEda3.uFKuOwD.58rwd7CFBg1O', 'Super Admin', 'Active', '0'),
('9', 'Hecil Gesite', 'hecilgesite95@gmail.com', '$2y$10$FGV.gOTWWNn2lJ3OThLRY.Q2wa0592Csb.09dH4XyUNR/7GyHQR.W', 'Admin', 'Inactive', '0'),
('14', 'Jasmin Claire', 'jsmnclredyro@gmail.com', '$2y$10$YKZSfkxCWclFmSKHbn6Kne8MwyMj9CqvbjJlWJASSnWGt5BsJRLla', 'Admin', 'Active', '0');

-- Table: activity_logs
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `category` varchar(30) NOT NULL,
  `action` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_number` varchar(30) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `target_type` varchar(30) DEFAULT NULL,
  `target_id` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user` (`user_name`),
  KEY `idx_category_action` (`category`,`action`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_logs` (`log_id`, `created_at`, `category`, `action`, `description`, `user_id`, `user_name`, `user_role`, `student_id`, `student_number`, `student_name`, `target_type`, `target_id`, `details`, `ip_address`, `user_agent`) VALUES
('1', '2026-10-05 20:51:01', 'audit', 'logs_exported', 'Exported 0 activity log record(s) to CSV', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"filters\":[],\"records\":0}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('2', '2026-10-05 21:17:11', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('3', '2026-10-05 21:17:22', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('4', '2026-10-05 21:28:48', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('5', '2026-10-05 21:28:57', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('6', '2026-10-05 21:29:09', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('7', '2026-10-07 17:06:14', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('8', '2026-10-07 17:52:38', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('9', '2026-10-07 17:52:52', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('10', '2026-10-07 18:40:07', 'backup', 'backup_created', 'Manual backup created: database only (11.6 KB)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'backup', '1', '{\"file_name\":\"pup_erecords_2026-10-07_184007_manual_f02e9e14.sql\",\"file_size\":\"11.6 KB\",\"tables\":6,\"rows\":22,\"uploaded_files\":\"Not included (the PHP zip extension is turned off)\",\"uploads_size\":null,\"checksum\":\"ed783d2a4d75ccf32d1df8b327ae300ac4129fa2aaf52f1e0478a25ab2c98cdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('11', '2026-10-07 18:45:39', 'backup', 'backup_created', 'Manual backup created: database + 14 uploaded file(s) (10.4 MB)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'backup', '2', '{\"file_name\":\"pup_erecords_2026-10-07_184538_manual_5d86e103.zip\",\"file_size\":\"10.4 MB\",\"tables\":6,\"rows\":24,\"uploaded_files\":14,\"uploads_size\":\"11.1 MB\",\"checksum\":\"edf70e0eef3f986498995b3139ca7b5f07505c5f3cafbe3343145defe57b167d\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('12', '2026-10-07 18:52:31', 'backup', 'backup_schedule_changed', 'Changed the backup schedule to Daily at 7:00 PM', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"changes\":{\"Schedule\":{\"from\":\"Daily at 2:00 AM\",\"to\":\"Daily at 7:00 PM\"}}}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0');

-- Table: backup_settings
DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `backup_settings` (`setting_key`, `setting_value`) VALUES
('frequency', 'daily'),
('time', '19:00'),
('updated_at', '2026-10-07 18:52:31'),
('weekday', '1');

-- Table: database_backups
DROP TABLE IF EXISTS `database_backups`;
CREATE TABLE `database_backups` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  `backup_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `table_count` int(11) DEFAULT NULL,
  `row_count` bigint(20) DEFAULT NULL,
  `upload_files` int(11) DEFAULT NULL,
  `checksum` char(64) DEFAULT NULL,
  `error_message` varchar(1000) DEFAULT NULL,
  `triggered_by` varchar(150) NOT NULL,
  `file_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `alert_dismissed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`backup_id`),
  KEY `idx_started_at` (`started_at`),
  KEY `idx_type_status` (`backup_type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `database_backups` (`backup_id`, `started_at`, `finished_at`, `backup_type`, `status`, `file_name`, `file_size`, `table_count`, `row_count`, `upload_files`, `checksum`, `error_message`, `triggered_by`, `file_deleted`, `alert_dismissed`) VALUES
('1', '2026-10-07 18:40:07', '2026-10-07 18:40:07', 'manual', 'success', 'pup_erecords_2026-10-07_184007_manual_f02e9e14.sql', '11870', '6', '22', NULL, 'ed783d2a4d75ccf32d1df8b327ae300ac4129fa2aaf52f1e0478a25ab2c98cdf', NULL, 'Alistair Ravena', '0', '0'),
('2', '2026-10-07 18:45:38', '2026-10-07 18:45:39', 'manual', 'success', 'pup_erecords_2026-10-07_184538_manual_5d86e103.zip', '10879467', '6', '24', '14', 'edf70e0eef3f986498995b3139ca7b5f07505c5f3cafbe3343145defe57b167d', NULL, 'Alistair Ravena', '0', '0'),
('3', '2026-10-07 19:00:33', NULL, 'scheduled', 'running', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'System', '0', '0');

-- Table: documents
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `document_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `document_type` varchar(100) NOT NULL DEFAULT 'Uploaded Document',
  `requirement_code` varchar(50) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_hash` char(64) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `added_by` varchar(150) DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`document_id`),
  UNIQUE KEY `uq_student_requirement` (`student_id`,`requirement_code`),
  UNIQUE KEY `uq_student_file_hash` (`student_id`,`file_hash`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `documents_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `documents` (`document_id`, `student_id`, `document_type`, `requirement_code`, `file_name`, `file_path`, `file_hash`, `uploaded_at`, `added_by`, `is_archived`, `archived_at`) VALUES
('29', '17', 'Route and Approval Slip', 'route_approval_slip', 'test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf', '../uploads/archive/2026/BS-PSYCH/1-1/2022-00200-BN-0 - RAMIREZ, JOSHUA DANIEL/test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf', '492cea9b7b5a22c4b55ebeeaf96c44b81771b145a69ae3e02c16ab3c1a56b873', '2026-10-04 18:21:13', 'Jasmin Claire', '1', '2026-10-04 18:21:13'),
('30', '18', 'Route and Approval Slip', 'route_approval_slip', 'test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf', '../uploads/documents/doc_6ac228ae2a42e0.64334377.pdf', 'caea8c6ae356c542006fc9c26414a1bc88d600d65f487f6c7ea9a38ae4dc3af3', '2026-10-04 18:22:26', 'Jasmin Claire', '0', NULL),
('31', '18', 'SAR Form 1 (Confirmation Slip)', 'sar_form', 'test_SARFORM2_2026-09-14_213929.pdf', '../uploads/documents/doc_6ac228b9aa8527.78720993.pdf', '5e430ae4ac07167bb4d50679b427aa243dad008614a859c47ce28776ba2f1ccf', '2026-10-04 18:22:26', 'Jasmin Claire', '0', NULL);

-- Table: students
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `student_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_number` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `course` varchar(100) NOT NULL,
  `year_section` varchar(20) NOT NULL,
  `graduation_year` smallint(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `sex` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `place_of_birth` varchar(150) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admission_track` varchar(20) NOT NULL DEFAULT 'shs_current',
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `student_number` (`student_number`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `students` (`student_id`, `student_number`, `name`, `last_name`, `first_name`, `middle_name`, `course`, `year_section`, `graduation_year`, `status`, `sex`, `date_of_birth`, `place_of_birth`, `address`, `mobile_number`, `email`, `photo_path`, `created_at`, `admission_track`) VALUES
('17', '2022-00200-BN-0', 'RAMIREZ, JOSHUA DANIEL', 'RAMIREZ', 'JOSHUA DANIEL', '', 'BS-PSYCH - Bachelor of Science in Psychology', '1-1', NULL, 'graduated', '', NULL, '', '', '', '', NULL, '2026-10-04 18:21:13', 'shs_current'),
('18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'VILLANUEVA', 'ANDREA MAE', '', 'BSCPE - Bachelor of Science in Computer Engineering', '1-2', NULL, 'active', 'Female', NULL, '', '', '', '', '../uploads/photos/photo_6ac228c5e939b6.92358455.png', '2026-10-04 18:22:26', 'shs_current');

-- Trigger: activity_logs_no_update
DROP TRIGGER IF EXISTS `activity_logs_no_update`;
DELIMITER ;;
CREATE TRIGGER `activity_logs_no_update` BEFORE UPDATE ON `activity_logs` FOR EACH ROW SIGNAL SQLSTATE '45000'
                                 SET MESSAGE_TEXT = 'Activity logs are read-only and cannot be modified.';;
DELIMITER ;

-- Trigger: activity_logs_no_delete
DROP TRIGGER IF EXISTS `activity_logs_no_delete`;
DELIMITER ;;
CREATE TRIGGER `activity_logs_no_delete` BEFORE DELETE ON `activity_logs` FOR EACH ROW SIGNAL SQLSTATE '45000'
                                 SET MESSAGE_TEXT = 'Activity logs are read-only and cannot be deleted.';;
DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
-- Backup completed: 2026-10-07 19:00:33 PST
