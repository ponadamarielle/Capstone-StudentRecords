PUP eRecords backup
Created: 2026-10-08 19:00:38 PST

database.sql  - the whole database (import it in phpMyAdmin)
uploads/      - copy this folder into the project folder (C:\xampp\htdocs\CAPSTONE)
