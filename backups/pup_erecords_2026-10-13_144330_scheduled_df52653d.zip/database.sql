-- PUP eRecords database backup
-- Database: db_pup_eRecords
-- Created: 2026-10-13 14:43:30 PST

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- Table: accounts
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'Registrar',
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `is_first_login` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `accounts` (`id`, `name`, `email`, `pass`, `role`, `status`, `is_first_login`) VALUES
('1', 'Alistair Ravena', 'superadmin@gmail.com', '$2y$10$L2YkceOwIXL7tHoDm04fseH7a1hEEda3.uFKuOwD.58rwd7CFBg1O', 'Super Admin', 'Active', '0'),
('9', 'Hecil Gesite', 'hecilgesite95@gmail.com', '$2y$10$FGV.gOTWWNn2lJ3OThLRY.Q2wa0592Csb.09dH4XyUNR/7GyHQR.W', 'Admin', 'Inactive', '0'),
('14', 'Jasmin Claire', 'jsmnclredyro@gmail.com', '$2y$10$YKZSfkxCWclFmSKHbn6Kne8MwyMj9CqvbjJlWJASSnWGt5BsJRLla', 'Admin', 'Active', '0'),
('16', 'Marielle Ponada', 'marielleponada@gmail.com', '$2y$10$eYGXP8oDR1imwEIFU1gpJeSXd6Ipzu20BkX6jDrghsmGw.f2yX90u', 'Admin', 'Active', '0');

-- Table: activity_logs
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `category` varchar(30) NOT NULL,
  `action` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_number` varchar(30) DEFAULT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `target_type` varchar(30) DEFAULT NULL,
  `target_id` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user` (`user_name`),
  KEY `idx_category_action` (`category`,`action`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_logs` (`log_id`, `created_at`, `category`, `action`, `description`, `user_id`, `user_name`, `user_role`, `student_id`, `student_number`, `student_name`, `target_type`, `target_id`, `details`, `ip_address`, `user_agent`) VALUES
('1', '2026-10-05 20:51:01', 'audit', 'logs_exported', 'Exported 0 activity log record(s) to CSV', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"filters\":[],\"records\":0}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('2', '2026-10-05 21:17:11', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('3', '2026-10-05 21:17:22', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('4', '2026-10-05 21:28:48', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('5', '2026-10-05 21:28:57', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('6', '2026-10-05 21:29:09', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('7', '2026-10-07 17:06:14', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('8', '2026-10-07 17:52:38', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('9', '2026-10-07 17:52:52', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('10', '2026-10-07 18:40:07', 'backup', 'backup_created', 'Manual backup created: database only (11.6 KB)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'backup', '1', '{\"file_name\":\"pup_erecords_2026-10-07_184007_manual_f02e9e14.sql\",\"file_size\":\"11.6 KB\",\"tables\":6,\"rows\":22,\"uploaded_files\":\"Not included (the PHP zip extension is turned off)\",\"uploads_size\":null,\"checksum\":\"ed783d2a4d75ccf32d1df8b327ae300ac4129fa2aaf52f1e0478a25ab2c98cdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('11', '2026-10-07 18:45:39', 'backup', 'backup_created', 'Manual backup created: database + 14 uploaded file(s) (10.4 MB)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'backup', '2', '{\"file_name\":\"pup_erecords_2026-10-07_184538_manual_5d86e103.zip\",\"file_size\":\"10.4 MB\",\"tables\":6,\"rows\":24,\"uploaded_files\":14,\"uploads_size\":\"11.1 MB\",\"checksum\":\"edf70e0eef3f986498995b3139ca7b5f07505c5f3cafbe3343145defe57b167d\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('12', '2026-10-07 18:52:31', 'backup', 'backup_schedule_changed', 'Changed the backup schedule to Daily at 7:00 PM', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"changes\":{\"Schedule\":{\"from\":\"Daily at 2:00 AM\",\"to\":\"Daily at 7:00 PM\"}}}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('13', '2026-10-07 19:00:34', 'backup', 'backup_created', 'Scheduled backup created: database + 14 uploaded file(s) (10.4 MB)', NULL, 'System', 'System', NULL, NULL, NULL, 'backup', '3', '{\"file_name\":\"pup_erecords_2026-10-07_190033_scheduled_ff1f62b3.zip\",\"file_size\":\"10.4 MB\",\"tables\":6,\"rows\":27,\"uploaded_files\":14,\"uploads_size\":\"11.1 MB\",\"checksum\":\"daaed40dd1b8402528d8a4ba2cfe00047ef595752fcd2cb7cbf9fbbd162f113d\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('14', '2026-10-07 19:03:40', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('15', '2026-10-07 19:03:52', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('16', '2026-10-07 19:04:39', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('17', '2026-10-07 19:04:47', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('18', '2026-10-07 19:05:28', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('19', '2026-10-07 19:05:36', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('20', '2026-10-07 19:07:04', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('21', '2026-10-07 19:07:10', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('22', '2026-10-07 19:15:19', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('23', '2026-10-08 13:19:11', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('24', '2026-10-08 13:39:28', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('25', '2026-10-08 14:15:20', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('26', '2026-10-08 16:11:10', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('27', '2026-10-08 16:11:18', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('28', '2026-10-08 16:31:13', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('29', '2026-10-08 16:31:26', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('30', '2026-10-08 16:31:37', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('31', '2026-10-08 16:35:42', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('32', '2026-10-08 16:35:53', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('33', '2026-10-08 16:36:28', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('34', '2026-10-08 16:42:39', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('35', '2026-10-08 16:42:59', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('36', '2026-10-08 16:43:18', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('37', '2026-10-08 16:43:38', 'authentication', 'login_failed', 'Failed sign-in attempt 1 of 3 for hecilgesite95@gmail.com', '9', 'Hecil Gesite', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"hecilgesite95@gmail.com\",\"reason\":\"Wrong password\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('38', '2026-10-08 16:43:42', 'authentication', 'login_failed', 'Failed sign-in attempt 2 of 3 for hecilgesite95@gmail.com', '9', 'Hecil Gesite', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"hecilgesite95@gmail.com\",\"reason\":\"Wrong password\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('39', '2026-10-08 16:43:45', 'authentication', 'login_failed', 'Failed sign-in attempt 3 of 3 for hecilgesite95@gmail.com', '9', 'Hecil Gesite', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"hecilgesite95@gmail.com\",\"reason\":\"Wrong password\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('40', '2026-10-08 16:43:45', 'authentication', 'account_locked', 'Sign-in locked for 5 minutes after 3 failed attempts for hecilgesite95@gmail.com', '9', 'Hecil Gesite', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"hecilgesite95@gmail.com\",\"locked_minutes\":5}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('41', '2026-10-08 16:44:17', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('42', '2026-10-08 16:45:13', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('43', '2026-10-08 16:45:22', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('44', '2026-10-08 16:45:52', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('45', '2026-10-08 16:46:48', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('46', '2026-10-08 16:47:00', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('47', '2026-10-08 16:52:30', 'authentication', 'account_status_changed', 'Deactivated Admin account of Jasmin Claire (jsmnclredyro@gmail.com)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'account', NULL, '{\"email\":\"jsmnclredyro@gmail.com\",\"changes\":{\"Status\":{\"from\":\"Active\",\"to\":\"Inactive\"}},\"effect\":\"The Admin is signed out on their next page load and can no longer sign in.\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('48', '2026-10-08 16:52:33', 'authentication', 'logout', 'Signed out automatically: the account was deactivated', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\",\"reason\":\"Account status is Inactive\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('49', '2026-10-08 16:52:57', 'authentication', 'account_status_changed', 'Activated Admin account of Jasmin Claire (jsmnclredyro@gmail.com)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'account', NULL, '{\"email\":\"jsmnclredyro@gmail.com\",\"changes\":{\"Status\":{\"from\":\"Inactive\",\"to\":\"Active\"}},\"effect\":\"The Admin can sign in again.\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('50', '2026-10-08 16:57:17', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('51', '2026-10-08 17:02:29', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('52', '2026-10-08 17:02:34', 'authentication', 'login', 'Signed in as Admin', '16', 'Marielle Ponada', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"marielleponada@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('53', '2026-10-08 17:05:13', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('54', '2026-10-08 17:05:33', 'authentication', 'login_failed', 'Failed sign-in attempt 1 of 3 for jsmnclredyro@gmail.com', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\",\"reason\":\"Wrong password\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('55', '2026-10-08 17:08:30', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('56', '2026-10-08 17:15:25', 'audit', 'logs_exported', 'Exported 25 activity log record(s) to CSV', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"filters\":{\"from\":\"2026-10-05\",\"to\":\"2026-10-08\",\"user\":\"Jasmin Claire\"},\"records\":25}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('57', '2026-10-08 17:25:53', 'authentication', 'password_changed', 'Changed the temporary password', NULL, 'Marielle Ponada', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"marielleponada@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('58', '2026-10-08 17:40:18', 'data_modification', 'student_created', 'Created student record pon, aa (2026-00201-HD-0)', NULL, 'Marielle Ponada', 'Admin', '19', '2026-00201-HD-0', 'pon, aa', 'student', '19', '{\"course\":\"BSIT - Bachelor of Science in Information Technology\",\"year_section\":\"2-1\",\"admission_track\":\"shs_current\",\"documents\":0}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('59', '2026-10-08 17:53:33', 'data_modification', 'student_created', 'Created student record REYES, ADRIAN MIGUEL C. (2022-00100-BN-0)', NULL, 'Marielle Ponada', 'Admin', '20', '2022-00100-BN-0', 'REYES, ADRIAN MIGUEL C.', 'student', '20', '{\"course\":\"BSIT - Bachelor of Science in Information Technology\",\"year_section\":\"4-1\",\"admission_track\":\"shs_current\",\"documents\":2}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('60', '2026-10-08 17:53:33', 'data_modification', 'document_uploaded', 'Uploaded SAR Form 1 (Confirmation Slip) \"Document_2026-09-28_210426 SAR FORM (MALE).pdf\" for REYES, ADRIAN MIGUEL C. (2022-00100-BN-0)', NULL, 'Marielle Ponada', 'Admin', '20', '2022-00100-BN-0', 'REYES, ADRIAN MIGUEL C.', 'document', NULL, '{\"file_name\":\"Document_2026-09-28_210426 SAR FORM (MALE).pdf\",\"document_type\":\"SAR Form 1 (Confirmation Slip)\",\"file_path\":\"../uploads/documents/doc_6ac767d53d66c9.54980002.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('61', '2026-10-08 17:53:33', 'data_modification', 'document_uploaded', 'Uploaded Route and Approval Slip \"Receipt_2026-09-28_213048 ROUTE AND APPROVAL SLIP (MALE).pdf\" for REYES, ADRIAN MIGUEL C. (2022-00100-BN-0)', NULL, 'Marielle Ponada', 'Admin', '20', '2022-00100-BN-0', 'REYES, ADRIAN MIGUEL C.', 'document', NULL, '{\"file_name\":\"Receipt_2026-09-28_213048 ROUTE AND APPROVAL SLIP (MALE).pdf\",\"document_type\":\"Route and Approval Slip\",\"file_path\":\"../uploads/documents/doc_6ac767eec86887.42303151.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('62', '2026-10-08 17:53:34', 'data_modification', 'student_auto_archived', 'Automatically archived REYES, ADRIAN MIGUEL C. (2022-00100-BN-0) as GRADUATE', NULL, 'System', 'System', '20', '2022-00100-BN-0', 'REYES, ADRIAN MIGUEL C.', 'student', '20', '{\"new_status\":\"graduated\",\"school_year_ended\":\"SY 2025-2026\",\"documents_moved\":2,\"reason\":\"Expected graduation school year has ended.\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('63', '2026-10-08 18:08:25', 'data_modification', 'document_deleted', 'Deleted Route and Approval Slip \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\" of VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Marielle Ponada', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', '30', '{\"file_name\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\",\"document_type\":\"Route and Approval Slip\",\"file_path\":\"../uploads/documents/doc_6ac228ae2a42e0.64334377.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('64', '2026-10-08 18:08:41', 'data_modification', 'document_deleted', 'Deleted SAR Form 1 (Confirmation Slip) \"test_SARFORM2_2026-09-14_213929.pdf\" of VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Marielle Ponada', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', '31', '{\"file_name\":\"test_SARFORM2_2026-09-14_213929.pdf\",\"document_type\":\"SAR Form 1 (Confirmation Slip)\",\"file_path\":\"../uploads/documents/doc_6ac228b9aa8527.78720993.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('65', '2026-10-08 18:09:35', 'data_modification', 'student_updated', 'Updated VILLANUEVA, ANDREA MAE (2026-00201-BN-0): Photo', NULL, 'Marielle Ponada', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'student', '18', '{\"changes\":{\"Photo\":{\"from\":\"Previous photo\",\"to\":\"New photo\"}}}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('66', '2026-10-08 18:09:36', 'data_modification', 'document_uploaded', 'Uploaded Route and Approval Slip \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\" for VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Marielle Ponada', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', NULL, '{\"file_name\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\",\"document_type\":\"Route and Approval Slip\",\"file_path\":\"../uploads/documents/doc_6ac76bbc9b1145.05166822.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('67', '2026-10-08 18:09:36', 'data_modification', 'document_uploaded', 'Uploaded SAR Form 1 (Confirmation Slip) \"test_SARFORM2_2026-09-14_213929.pdf\" for VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Marielle Ponada', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', NULL, '{\"file_name\":\"test_SARFORM2_2026-09-14_213929.pdf\",\"document_type\":\"SAR Form 1 (Confirmation Slip)\",\"file_path\":\"../uploads/documents/doc_6ac76bd56fbb49.76900307.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('68', '2026-10-08 18:11:27', 'authentication', 'logout', 'Signed out', NULL, 'Marielle Ponada', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"marielleponada@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('69', '2026-10-08 18:15:19', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('70', '2026-10-08 18:19:27', 'data_modification', 'document_deleted', 'Deleted Route and Approval Slip \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\" of VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', '34', '{\"file_name\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\",\"document_type\":\"Route and Approval Slip\",\"file_path\":\"../uploads/documents/doc_6ac76bbc9b1145.05166822.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('71', '2026-10-08 18:21:36', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('72', '2026-10-08 18:22:36', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('73', '2026-10-08 18:28:37', 'data_modification', 'student_updated', 'Saved VILLANUEVA, ANDREA MAE (2026-00201-BN-0) (no field changes)', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'student', '18', '{\"changes\":[]}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('74', '2026-10-08 18:28:38', 'data_modification', 'document_uploaded', 'Uploaded Route and Approval Slip \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\" for VILLANUEVA, ANDREA MAE (2026-00201-BN-0)', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', NULL, '{\"file_name\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\",\"document_type\":\"Route and Approval Slip\",\"file_path\":\"../uploads/documents/doc_6ac7704670ab68.29106629.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('75', '2026-10-08 18:29:08', 'data_modification', 'student_updated', 'Updated VILLANUEVA, ANDREA MAE (2026-00201-BN-0): Place of Birth', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'student', '18', '{\"changes\":{\"Place of Birth\":{\"from\":\"\",\"to\":\"Binan Laguna\"}}}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('76', '2026-10-08 18:31:01', 'data_modification', 'document_replaced', 'Replaced Route and Approval Slip of VILLANUEVA, ANDREA MAE (2026-00201-BN-0): \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\" → \"test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf\"', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', '36', '{\"changes\":{\"File\":{\"from\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\",\"to\":\"test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf\"}},\"new_file_path\":\"../uploads/documents/doc_6ac770e30769e6.24859420.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('77', '2026-10-08 18:37:03', 'data_modification', 'student_updated', 'Saved VILLANUEVA, ANDREA MAE (2026-00201-BN-0) (no field changes)', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'student', '18', '{\"changes\":[]}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('78', '2026-10-08 18:37:04', 'data_modification', 'document_replaced', 'Replaced Route and Approval Slip of VILLANUEVA, ANDREA MAE (2026-00201-BN-0): \"test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf\" → \"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\"', NULL, 'Jasmin Claire', 'Admin', '18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'document', '36', '{\"changes\":{\"File\":{\"from\":\"test_ROUTEandAPPROVALSLIP3_2026-09-14_214653.pdf\",\"to\":\"test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf\"}},\"new_file_path\":\"../uploads/documents/doc_6ac7724049dfb7.45951435.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('79', '2026-10-08 18:40:11', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('80', '2026-10-08 18:41:41', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('81', '2026-10-08 19:00:39', 'backup', 'backup_created', 'Scheduled backup created: database + 16 uploaded file(s) (9.8 MB)', NULL, 'System', 'System', NULL, NULL, NULL, 'backup', '4', '{\"file_name\":\"pup_erecords_2026-10-08_190038_scheduled_dc1c16a1.zip\",\"file_size\":\"9.8 MB\",\"tables\":7,\"rows\":99,\"uploaded_files\":16,\"uploads_size\":\"10.4 MB\",\"checksum\":\"db4c9acc79e03f2b305368a3e493aea38857f3edc14cb1f71c0005b5d22efa59\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('82', '2026-10-08 19:02:18', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'),
('83', '2026-10-09 14:35:49', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('84', '2026-10-09 14:39:56', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('85', '2026-10-09 14:40:09', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('86', '2026-10-09 14:40:28', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('87', '2026-10-09 14:41:56', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('88', '2026-10-09 14:43:43', 'data_modification', 'student_created', 'Created student record REYES, ADRIAN MIGUEL C. (2026-00205-BN-0)', NULL, 'Jasmin Claire', 'Admin', '21', '2026-00205-BN-0', 'REYES, ADRIAN MIGUEL C.', 'student', '21', '{\"course\":\"BSIT - Bachelor of Science in Information Technology\",\"year_section\":\"1-1\",\"admission_track\":\"shs_current\",\"documents\":1}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('89', '2026-10-09 14:43:43', 'data_modification', 'document_uploaded', 'Uploaded SAR Form 1 (Confirmation Slip) \"Document_2026-09-28_210426 SAR FORM (MALE).pdf\" for REYES, ADRIAN MIGUEL C. (2026-00205-BN-0)', NULL, 'Jasmin Claire', 'Admin', '21', '2026-00205-BN-0', 'REYES, ADRIAN MIGUEL C.', 'document', NULL, '{\"file_name\":\"Document_2026-09-28_210426 SAR FORM (MALE).pdf\",\"document_type\":\"SAR Form 1 (Confirmation Slip)\",\"file_path\":\"../uploads/documents/doc_6ac88cd0468562.98772090.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('90', '2026-10-09 14:45:42', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('91', '2026-10-09 14:45:55', 'authentication', 'login', 'Signed in as Super Admin', '1', 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('92', '2026-10-09 14:47:13', 'authentication', 'account_status_changed', 'Deactivated Admin account of Hecil Gesite (hecilgesite95@gmail.com)', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, 'account', NULL, '{\"email\":\"hecilgesite95@gmail.com\",\"changes\":{\"Status\":{\"from\":\"Active\",\"to\":\"Inactive\"}},\"effect\":\"The Admin is signed out on their next page load and can no longer sign in.\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('93', '2026-10-09 14:50:44', 'authentication', 'logout', 'Signed out', NULL, 'Alistair Ravena', 'Super Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"superadmin@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('94', '2026-10-09 14:50:54', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('95', '2026-10-09 14:51:14', 'authentication', 'logout', 'Signed out', NULL, 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0'),
('96', '2026-10-13 14:43:30', 'authentication', 'login', 'Signed in as Admin', '14', 'Jasmin Claire', 'Admin', NULL, NULL, NULL, NULL, NULL, '{\"email\":\"jsmnclredyro@gmail.com\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0');

-- Table: backup_settings
DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `backup_settings` (`setting_key`, `setting_value`) VALUES
('frequency', 'daily'),
('time', '19:00'),
('updated_at', '2026-10-07 18:52:31'),
('weekday', '1');

-- Table: database_backups
DROP TABLE IF EXISTS `database_backups`;
CREATE TABLE `database_backups` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  `backup_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `table_count` int(11) DEFAULT NULL,
  `row_count` bigint(20) DEFAULT NULL,
  `upload_files` int(11) DEFAULT NULL,
  `checksum` char(64) DEFAULT NULL,
  `error_message` varchar(1000) DEFAULT NULL,
  `triggered_by` varchar(150) NOT NULL,
  `file_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `alert_dismissed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`backup_id`),
  KEY `idx_started_at` (`started_at`),
  KEY `idx_type_status` (`backup_type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `database_backups` (`backup_id`, `started_at`, `finished_at`, `backup_type`, `status`, `file_name`, `file_size`, `table_count`, `row_count`, `upload_files`, `checksum`, `error_message`, `triggered_by`, `file_deleted`, `alert_dismissed`) VALUES
('1', '2026-10-07 18:40:07', '2026-10-07 18:40:07', 'manual', 'success', 'pup_erecords_2026-10-07_184007_manual_f02e9e14.sql', '11870', '6', '22', NULL, 'ed783d2a4d75ccf32d1df8b327ae300ac4129fa2aaf52f1e0478a25ab2c98cdf', NULL, 'Alistair Ravena', '0', '0'),
('2', '2026-10-07 18:45:38', '2026-10-07 18:45:39', 'manual', 'success', 'pup_erecords_2026-10-07_184538_manual_5d86e103.zip', '10879467', '6', '24', '14', 'edf70e0eef3f986498995b3139ca7b5f07505c5f3cafbe3343145defe57b167d', NULL, 'Alistair Ravena', '0', '0'),
('3', '2026-10-07 19:00:33', '2026-10-07 19:00:34', 'scheduled', 'success', 'pup_erecords_2026-10-07_190033_scheduled_ff1f62b3.zip', '10879699', '6', '27', '14', 'daaed40dd1b8402528d8a4ba2cfe00047ef595752fcd2cb7cbf9fbbd162f113d', NULL, 'System', '0', '0'),
('4', '2026-10-08 19:00:38', '2026-10-08 19:00:39', 'scheduled', 'success', 'pup_erecords_2026-10-08_190038_scheduled_dc1c16a1.zip', '10255016', '7', '99', '16', 'db4c9acc79e03f2b305368a3e493aea38857f3edc14cb1f71c0005b5d22efa59', NULL, 'System', '0', '0'),
('5', '2026-10-13 14:43:30', NULL, 'scheduled', 'running', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'System', '0', '0');

-- Table: documents
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `document_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `document_type` varchar(100) NOT NULL DEFAULT 'Uploaded Document',
  `requirement_code` varchar(50) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_hash` char(64) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `added_by` varchar(150) DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`document_id`),
  UNIQUE KEY `uq_student_requirement` (`student_id`,`requirement_code`),
  UNIQUE KEY `uq_student_file_hash` (`student_id`,`file_hash`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `documents_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `documents` (`document_id`, `student_id`, `document_type`, `requirement_code`, `file_name`, `file_path`, `file_hash`, `uploaded_at`, `added_by`, `is_archived`, `archived_at`) VALUES
('32', '20', 'SAR Form 1 (Confirmation Slip)', 'sar_form', 'Document_2026-09-28_210426 SAR FORM (MALE).pdf', '../uploads/archive/2026/BSIT/4-1/2022-00100-BN-0 - REYES, ADRIAN MIGUEL C/Document_2026-09-28_210426 SAR FORM (MALE).pdf', 'fa1b448358cf153be8d59251cfe2c1282a7284df09e1032d88ac16682e2bfa34', '2026-10-08 17:53:33', 'Marielle Ponada', '1', '2026-10-08 17:53:34'),
('33', '20', 'Route and Approval Slip', 'route_approval_slip', 'Receipt_2026-09-28_213048 ROUTE AND APPROVAL SLIP (MALE).pdf', '../uploads/archive/2026/BSIT/4-1/2022-00100-BN-0 - REYES, ADRIAN MIGUEL C/Receipt_2026-09-28_213048 ROUTE AND APPROVAL SLIP (MALE).pdf', '2e2cf35cda0717efb56f8d74d5e14063cedc12df036c0e81b78e4fae533fcccd', '2026-10-08 17:53:33', 'Marielle Ponada', '1', '2026-10-08 17:53:34'),
('35', '18', 'SAR Form 1 (Confirmation Slip)', 'sar_form', 'test_SARFORM2_2026-09-14_213929.pdf', '../uploads/documents/doc_6ac76bd56fbb49.76900307.pdf', '5e430ae4ac07167bb4d50679b427aa243dad008614a859c47ce28776ba2f1ccf', '2026-10-08 18:09:36', 'Marielle Ponada', '0', NULL),
('36', '18', 'Route and Approval Slip', 'route_approval_slip', 'test_ROUTEandAPPROVALSLIP2_2026-09-14_214223.pdf', '../uploads/documents/doc_6ac7724049dfb7.45951435.pdf', 'caea8c6ae356c542006fc9c26414a1bc88d600d65f487f6c7ea9a38ae4dc3af3', '2026-10-08 18:37:04', 'Jasmin Claire', '0', NULL),
('37', '21', 'SAR Form 1 (Confirmation Slip)', 'sar_form', 'Document_2026-09-28_210426 SAR FORM (MALE).pdf', '../uploads/documents/doc_6ac88cd0468562.98772090.pdf', 'fa1b448358cf153be8d59251cfe2c1282a7284df09e1032d88ac16682e2bfa34', '2026-10-09 14:43:43', 'Jasmin Claire', '0', NULL);

-- Table: login_attempts
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `email` varchar(255) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_attempt` datetime NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `login_attempts` (`email`, `attempts`, `locked_until`, `last_attempt`) VALUES
('hecilgesite95@gmail.com', '3', '2026-10-08 16:48:45', '2026-10-08 16:43:45');

-- Table: students
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `student_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_number` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `course` varchar(100) NOT NULL,
  `year_section` varchar(20) NOT NULL,
  `graduation_year` smallint(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `sex` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `place_of_birth` varchar(150) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admission_track` varchar(20) NOT NULL DEFAULT 'shs_current',
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `student_number` (`student_number`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `students` (`student_id`, `student_number`, `name`, `last_name`, `first_name`, `middle_name`, `course`, `year_section`, `graduation_year`, `status`, `sex`, `date_of_birth`, `place_of_birth`, `address`, `mobile_number`, `email`, `photo_path`, `created_at`, `admission_track`) VALUES
('18', '2026-00201-BN-0', 'VILLANUEVA, ANDREA MAE', 'VILLANUEVA', 'ANDREA MAE', '', 'BSCPE - Bachelor of Science in Computer Engineering', '1-2', NULL, 'active', 'Female', NULL, 'Binan Laguna', '', '', '', '../uploads/photos/photo_6ac76bd979ced5.65445273.png', '2026-10-04 18:22:26', 'shs_current'),
('20', '2022-00100-BN-0', 'REYES, ADRIAN MIGUEL C.', 'REYES', 'ADRIAN MIGUEL', 'C.', 'BSIT - Bachelor of Science in Information Technology', '4-1', NULL, 'graduated', 'Male', NULL, '', '', '', '', '../uploads/photos/photo_6ac767dd0a0ad4.49685667.png', '2026-10-08 17:53:33', 'shs_current'),
('21', '2026-00205-BN-0', 'REYES, ADRIAN MIGUEL C.', 'REYES', 'ADRIAN MIGUEL', 'C.', 'BSIT - Bachelor of Science in Information Technology', '1-1', NULL, 'active', 'Male', NULL, '', '', '', '', '../uploads/photos/photo_6ac88cdd42d5e4.28661380.png', '2026-10-09 14:43:43', 'shs_current');

-- Trigger: activity_logs_no_update
DROP TRIGGER IF EXISTS `activity_logs_no_update`;
DELIMITER ;;
CREATE TRIGGER `activity_logs_no_update` BEFORE UPDATE ON `activity_logs` FOR EACH ROW SIGNAL SQLSTATE '45000'
                                 SET MESSAGE_TEXT = 'Activity logs are read-only and cannot be modified.';;
DELIMITER ;

-- Trigger: activity_logs_no_delete
DROP TRIGGER IF EXISTS `activity_logs_no_delete`;
DELIMITER ;;
CREATE TRIGGER `activity_logs_no_delete` BEFORE DELETE ON `activity_logs` FOR EACH ROW SIGNAL SQLSTATE '45000'
                                 SET MESSAGE_TEXT = 'Activity logs are read-only and cannot be deleted.';;
DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
-- Backup completed: 2026-10-13 14:43:30 PST
